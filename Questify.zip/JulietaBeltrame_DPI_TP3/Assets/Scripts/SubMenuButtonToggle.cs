using UnityEngine;

public class SubMenuButtonToggle : MonoBehaviour
{
    public GameObject[] buttonsToShow; // Botones del submenú.
    public GameObject mainMenuButton; // Botón que abre el submenú.
    private bool isSubMenuActive = false; // Estado del submenú.

    void Start()
    {
        // Desactivar los botones del submenú al inicio.
        CloseSubMenu();
    }

    // Método para alternar el estado del submenú.
    public void ToggleSubMenu()
    {
        if (isSubMenuActive)
        {
            CloseSubMenu();
        }
        else
        {
            OpenSubMenu();
        }

        isSubMenuActive = !isSubMenuActive;
    }

    // Abre el submenú.
    private void OpenSubMenu()
    {
        foreach (var button in buttonsToShow)
        {
            if (button != null)
            {
                button.SetActive(true);
            }
        }
    }

    // Cierra el submenú.
    private void CloseSubMenu()
    {
        foreach (var button in buttonsToShow)
        {
            if (button != null)
            {
                button.SetActive(false);
            }
        }
    }

    // Método para borrar el botón principal que abre el submenú.
    public void DeleteMainMenuButton()
    {
        if (mainMenuButton != null)
        {
            // Desactivar cualquier componente interactable antes de eliminar el botón
            var interactable = mainMenuButton.GetComponent<Oculus.Interaction.InteractableColorVisual>();
            if (interactable != null)
            {
                interactable.enabled = false;
            }

            // Ahora destruir o desactivar el botón
            Destroy(mainMenuButton);
        }

        // Cierra el submenú y asegura el estado correcto
        CloseSubMenu();
        isSubMenuActive = false;
    }


}