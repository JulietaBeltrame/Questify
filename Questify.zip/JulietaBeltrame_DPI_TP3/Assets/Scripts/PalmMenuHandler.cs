using TMPro;
using UnityEngine;

namespace Oculus.Interaction.Samples.PalmMenu
{
    public class PalmMenuHandler : MonoBehaviour
    {
        [SerializeField]
        private GameObject _HandEnabledIcon;

        [SerializeField]
        private GameObject _HandDisabledIcon;

        [SerializeField]
        private GameObject _MicrophoneEnabledIcon;

        [SerializeField]
        private GameObject _MicrophoneDisabledIcon;

        [SerializeField]
        private GameObject _SessionEnabledIcon;

        [SerializeField]
        private GameObject _SessionDisabledIcon;

        private void Start()
        {
            // Set default states
            SetHandIconState(false);
            SetMicrophoneIconState(false);
            SetSessionIconState(false);
        }

        // Toggle Hand icons
        public void ToggleHandIcon()
        {
            bool isHandEnabled = _HandEnabledIcon.activeSelf;
            SetHandIconState(!isHandEnabled);
        }

        private void SetHandIconState(bool enabled)
        {
            _HandEnabledIcon.SetActive(enabled);
            _HandDisabledIcon.SetActive(!enabled);
        }

        // Toggle Microphone icons
        public void ToggleMicrophoneIcon()
        {
            bool isMicrophoneEnabled = _MicrophoneEnabledIcon.activeSelf;
            SetMicrophoneIconState(!isMicrophoneEnabled);
        }

        private void SetMicrophoneIconState(bool enabled)
        {
            _MicrophoneEnabledIcon.SetActive(enabled);
            _MicrophoneDisabledIcon.SetActive(!enabled);
        }

        // Toggle Session icons
        public void ToggleSessionIcon()
        {
            bool isSessionEnabled = _SessionEnabledIcon.activeSelf;
            SetSessionIconState(!isSessionEnabled);
        }

        private void SetSessionIconState(bool enabled)
        {
            _SessionEnabledIcon.SetActive(enabled);
            _SessionDisabledIcon.SetActive(!enabled);
        }
    }
}
