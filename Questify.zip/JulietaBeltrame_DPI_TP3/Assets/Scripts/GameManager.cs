using System.Collections;
using UnityEngine;
using TMPro; // Para usar TextMeshPro

public class GameManager : MonoBehaviour
{
    public static GameManager Instance; // Singleton para fácil acceso.

    [Header("UI Panels")]
    public GameObject codePanel;          // Panel inicial donde se genera el código.
    public GameObject waitingPanel;       // Panel de "Esperando jugadores".
    public TextMeshProUGUI waitingText;   // Texto donde se mostrará el código en el panel de espera.

    [Header("Palm Menu Hand")]
    public GameObject palmMenuHand;       // El menú de la mano (Palm Menu Hand) inicialmente desactivado.

    private void Awake()
    {
        // Configurar el Singleton
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    // Método que se llama cuando se genera el código.
    public void OnCodeGenerated(string code)
    {
        StartCoroutine(HandlePanelTransition(code));
    }

    // Corutina para manejar la transición entre paneles.
    private IEnumerator HandlePanelTransition(string code)
    {
        // Esperar 1.5 segundos.
        yield return new WaitForSeconds(1.5f);

        // Ocultar el panel del código y mostrar el panel de espera.
        codePanel.SetActive(false);
        waitingPanel.SetActive(true);

        // Actualizar el texto del panel de espera con el código generado.
        if (waitingText != null)
        {
            waitingText.text = $"Código: {code}";
        }

        // Activar el Palm Menu Hand.
        if (palmMenuHand != null)
        {
            palmMenuHand.SetActive(true);
        }
        else
        {
            Debug.LogWarning("Palm Menu Hand no está asignado en el inspector.");
        }
    }
}