using UnityEngine;

public class OpenCanvasOnButtonPress : MonoBehaviour
{
    public GameObject canvasToOpen;  // El Canvas que deseas abrir.
    private static GameObject currentlyOpenCanvas;  // Variable estática para controlar el Canvas abierto.

    void Start()
    {
        // Desactivar el Canvas al inicio.
        canvasToOpen.SetActive(false); 
    }

    // Este método se llama cuando el botón es presionado.
    public void OpenCanvas()
    {
        if (canvasToOpen != null)
        {
            // Si ya hay un canvas abierto, lo cerramos antes de abrir el nuevo
            if (currentlyOpenCanvas != null && currentlyOpenCanvas != canvasToOpen)
            {
                currentlyOpenCanvas.SetActive(false);  // Cerrar el Canvas actualmente abierto.
            }

            // Verificar si el Canvas a abrir ya está activo
            if (!canvasToOpen.activeSelf)
            {
                canvasToOpen.SetActive(true);  // Hacer visible el Canvas si no está activo.
                currentlyOpenCanvas = canvasToOpen;  // Guardar el Canvas que está abierto actualmente.
            }
            else
            {
                Debug.Log("El Canvas ya está abierto.");
            }
        }
        else
        {
            Debug.LogWarning("No se ha asignado un Canvas para abrir.");
        }
    }
}
