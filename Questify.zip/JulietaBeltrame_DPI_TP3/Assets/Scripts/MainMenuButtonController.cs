using UnityEngine;

public class MainMenuButtonController : MonoBehaviour
{
    public GameObject[] mainMenuButtons;  // Botones principales del menú.
    public GameObject[] subMenus;         // Submenús asociados a los botones principales.
    private int currentSubMenuIndex = -1; // Índice del submenú abierto actualmente (si hay alguno abierto).

    // Este método se debe asignar a los botones principales desde el editor o código.
    public void OnMainMenuButtonClicked(int buttonIndex)
    {
        // Si hay un submenú abierto, ciérralo.
        if (currentSubMenuIndex != -1)
        {
            CloseSubMenu(currentSubMenuIndex);
        }

        // Abre el submenú correspondiente al botón seleccionado.
        OpenSubMenu(buttonIndex);

        // Actualiza el índice del submenú actual.
        currentSubMenuIndex = buttonIndex;
    }

    // Abre el submenú correspondiente al índice.
    private void OpenSubMenu(int subMenuIndex)
    {
        if (subMenus[subMenuIndex] != null)
        {
            subMenus[subMenuIndex].SetActive(true); // Activar el submenú.
        }
    }

    // Cierra el submenú correspondiente al índice.
    private void CloseSubMenu(int subMenuIndex)
    {
        if (subMenus[subMenuIndex] != null)
        {
            subMenus[subMenuIndex].SetActive(false); // Desactivar el submenú.
        }
    }
}
