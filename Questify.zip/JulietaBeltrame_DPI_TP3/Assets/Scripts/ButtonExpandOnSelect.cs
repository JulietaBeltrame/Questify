using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButtonExpandOnSelect : MonoBehaviour
{
    public GameObject colorPlane; // El plano de color que aparecerá debajo del botón.
    public GameObject modelPrefab; // Prefab del modelo 3D que aparecerá encima del plano.
    public Vector3 expandedPlaneScale = new Vector3(0.1f, 0.5f, 0.1f); // Escala expandida en el eje Y del plano.
    public Color planeColor = new Color(0.835f, 0.933f, 0.616f); // Color #D5EE9D en formato RGB.
    public float moveOffsetY = -0.3f; // Cantidad que el plano se moverá hacia arriba (en Y local).
    public float modelOffsetY = 0.2f; // Altura relativa del modelo 3D encima del plano.
    public float modelScale = 0.6f;

    public List<GameObject> subMenus; // Lista de submenús que se desplegarán cuando se seleccione el modelo 3D.
    public float subMenuOffsetY = 0.3f; // Distancia a la que se posicionará el submenú respecto al modelo 3D.
    public Vector3 subMenuOffsetPosition = new Vector3(0.5f, 0, 0); // Ajuste adicional para la posición en el eje X.

    private Vector3 originalPlaneScale; // Escala original del plano.
    private Vector3 originalPlanePosition; // Posición original del plano.
    private GameObject instantiatedPlane; // Referencia al plano instanciado.
    private GameObject instantiatedModel; // Referencia al modelo 3D instanciado.
    private bool isExpanded = false; // Estado del botón (expandido o no).
    private bool isSubMenuActive = false; // Estado del submenú (activo o no).
    private List<Vector3> subMenuInitialPositions = new List<Vector3>(); // Lista para guardar las posiciones iniciales de los submenús.

    void Start()
    {
        // Crear el plano inicialmente y desactivarlo.
        instantiatedPlane = GameObject.CreatePrimitive(PrimitiveType.Quad);
        instantiatedPlane.transform.SetParent(transform.parent, false); // Asegurarse de que el plano sea relativo al padre.
        instantiatedPlane.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f); // Escala inicial del plano en el sistema local.
        instantiatedPlane.transform.localPosition = transform.localPosition + new Vector3(0, -0.1f, 0); // Posición inicial debajo del botón.
        instantiatedPlane.GetComponent<Renderer>().material.color = planeColor;
        instantiatedPlane.SetActive(false);

        // Guardar la escala y posición originales del plano.
        originalPlaneScale = instantiatedPlane.transform.localScale;
        originalPlanePosition = instantiatedPlane.transform.localPosition;

        // Inicializar el modelo 3D pero desactivarlo.
        if (modelPrefab != null)
        {
            instantiatedModel = Instantiate(modelPrefab, transform.parent); // Instanciar el modelo como hijo del padre.
            instantiatedModel.transform.localScale = Vector3.one * modelScale; // Escalar el modelo (ajustable según el prefab).
            instantiatedModel.transform.localPosition = instantiatedPlane.transform.localPosition + new Vector3(0, 0.3f, 0); // Posición inicial.
            instantiatedModel.SetActive(false);
        }
        else
        {
            Debug.LogWarning("No se ha asignado un prefab para el modelo 3D.");
        }

        // Asegúrate de que todos los submenús estén desactivados al inicio.
        foreach (var menu in subMenus)
        {
            if (menu != null)
            {
                menu.SetActive(false);
                // Guardar la posición inicial de cada submenú en la escena.
                subMenuInitialPositions.Add(menu.transform.localPosition);
            }
        }
    }

    // Este método se llama al interactuar con el botón.
    public void Toggle()
    {
        if (isExpanded)
        {
            Collapse(); // Si está expandido, colapsar.
        }
        else
        {
            Expand(); // Si está colapsado, expandir.
        }
        isExpanded = !isExpanded; // Cambiar el estado.
    }

    private void Expand()
    {
        // Activar el plano.
        instantiatedPlane.SetActive(true);

        // Ajustar la escala del plano en el eje Y.
        instantiatedPlane.transform.localScale = new Vector3(
            instantiatedPlane.transform.localScale.x,  // Mantener la escala X.
            expandedPlaneScale.y,                      // Ajustar la altura local del plano.
            instantiatedPlane.transform.localScale.z); // Mantener la escala Z.

        // Mover el plano hacia arriba en el eje Y local.
        instantiatedPlane.transform.localPosition = originalPlanePosition + new Vector3(0, moveOffsetY, 0);

        // Activar el modelo 3D y posicionarlo encima del plano.
        if (instantiatedModel != null)
        {
            instantiatedModel.SetActive(true);

            // Centrar el modelo respecto al plano.
            instantiatedModel.transform.localPosition = instantiatedPlane.transform.localPosition + new Vector3(0, modelOffsetY, -0.1f);

            // Rotar el modelo en el eje X.
            instantiatedModel.transform.localRotation = Quaternion.Euler(0f, 0f, -40f); // Ajusta el ángulo en X (30° como ejemplo).

            // Ajustar la escala del modelo en el eje Y.
            instantiatedModel.transform.localScale = new Vector3(
                instantiatedModel.transform.localScale.x,  // Mantener la escala X.
                instantiatedModel.transform.localScale.y,  // Cambiar la escala en Y (1.5x como ejemplo).
                instantiatedModel.transform.localScale.z); // Mantener la escala Z.
        }

        // Activar todos los submenús si el modelo está activo.
        foreach (var menu in subMenus)
        {
            if (menu != null && !menu.activeSelf)
            {
                menu.SetActive(true);

                // Usar la posición guardada previamente para colocar el submenú en su lugar.
                int index = subMenus.IndexOf(menu);
                if (index >= 0 && index < subMenuInitialPositions.Count)
                {
                    menu.transform.localPosition = subMenuInitialPositions[index] + new Vector3(subMenuOffsetPosition.x, subMenuOffsetY, 0);
                }
            }
        }
    }

    private void Collapse()
    {
        // Restaurar la escala original del plano.
        instantiatedPlane.transform.localScale = originalPlaneScale;

        // Restaurar la posición original del plano.
        instantiatedPlane.transform.localPosition = originalPlanePosition;

        // Desactivar el plano.
        instantiatedPlane.SetActive(false);

        // Desactivar el modelo 3D.
        if (instantiatedModel != null)
        {
            instantiatedModel.SetActive(false);
        }

        // Desactivar todos los submenús si estaban activos.
        foreach (var menu in subMenus)
        {
            if (menu != null && menu.activeSelf)
            {
                menu.SetActive(false);
            }
        }
    }
}
