using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro; // Para usar TextMeshPro

public class GenerateCodeOnButtonSelect : MonoBehaviour
{
    public TextMeshProUGUI targetText; // El componente de texto donde se mostrará el código.
    public int codeLength = 6;        // La longitud del código alfanumérico.
    private string generatedCode;     // Código generado (se guarda para otros scripts).

    // Método que genera el código y lo asigna al texto.
    public void GenerateCode()
    {
        generatedCode = GenerateAlphanumericCode(codeLength);
        if (targetText != null)
        {
            targetText.text = generatedCode; // Asigna el código al texto.
        }
        else
        {
            Debug.LogWarning("Target Text no está asignado en el inspector.");
        }

        // Notifica al GameManager que el código fue generado.
        GameManager.Instance.OnCodeGenerated(generatedCode);
    }

    // Método para generar un código alfanumérico aleatorio.
    private string GenerateAlphanumericCode(int length)
    {
        const string characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        char[] codeArray = new char[length];
        for (int i = 0; i < length; i++)
        {
            codeArray[i] = characters[Random.Range(0, characters.Length)];
        }
        return new string(codeArray);
    }
}